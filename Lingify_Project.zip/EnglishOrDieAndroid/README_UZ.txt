ENGLISH OR DIE — ANDROID LOYIHA SKELETI
==========================================

Bu Android Studio uchun boshlang'ich loyiha. Ilova ichida offline HTML/JavaScript
o'quv interfeysi Android WebView orqali ochiladi.

HOZIR BOR:
- Kunlik topshiriqlar va XP
- 5 ta boshlang'ich so'z
- Mini test
- Ovozli o'qish (Android TTS/brauzer qo'llab-quvvatlashiga bog'liq)
- Natijalarni qurilmada saqlash (localStorage)

HOZIRCHA YO'Q:
- AI ustoz/API ulanishi
- Kafolatlangan fon bildirishnomalari
- Foydalanuvchi akkaunti va bulutli sinxronlash
- Play Store uchun imzolangan release

APK YIG'ISH:
1. Android Studio o'rnating.
2. Ushbu ZIP faylni papkaga oching.
3. Android Studio -> Open orqali EnglishOrDie papkasini tanlang.
4. Gradle sync tugashini kuting.
5. Test uchun: Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. APK odatda app/build/outputs/apk/debug/app-debug.apk ichida bo'ladi.

Eslatma: Android Studio va mos Android SDK kerak. Bu muhitda APK build qilinmagan,
shuning uchun ZIP tayyor loyiha manbasi, o'rnatishga tayyor APK emas.
